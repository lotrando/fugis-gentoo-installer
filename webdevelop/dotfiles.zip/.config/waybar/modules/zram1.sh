#!/bin/bash

exec 2>/dev/null

if [ ! -e /dev/zram1 ]; then
    echo "missing"
    exit 0
fi

if command -v zramctl >/dev/null; then
    info=$(zramctl /dev/zram1 --noheadings 2>/dev/null)
    if [ -n "$info" ]; then
        disksize=$(echo "$info" | awk '{print $3}')
        data=$(echo "$info" | awk '{print $4}')
        echo "$data/$disksize"
    else
        echo "inactive"
    fi
else
    echo "no zramctl"
fi
