## Current Theme

type="$HOME/.config/rofi/applets/config"
style='style.rasi'
