#!/bin/bash

TEMP_PATH="/sys/class/drm/card0/device/hwmon/hwmon3/temp1_input"

get_temperature() {
    if [[ -r "$TEMP_PATH" ]]; then
        temp=$(cat "$TEMP_PATH")
        echo $((temp / 1000))
    elif [[ -r "$ALT_TEMP_PATH" ]]; then
        temp=$(cat "$ALT_TEMP_PATH")
        echo $((temp / 1000))
    else
        if command -v sensors >/dev/null 2>&1; then
            sensors | grep -E "(amdgpu|radeon)" -A 10 | grep -E "temp.*°C" | head -1 | grep -oE '[0-9]+' | head -1
        else
            echo "N/A"
        fi
    fi
}

TEMP=$(get_temperature)

if [[ "$TEMP" =~ ^[0-9]+$ ]]; then
    if [ "$TEMP" -lt 50 ]; then
        TEMP_CLASS="cold"
    elif [ "$TEMP" -lt 70 ]; then
        TEMP_CLASS="normal"
    elif [ "$TEMP" -lt 80 ]; then
        TEMP_CLASS="warm"
    else
        TEMP_CLASS="hot"
    fi
else
    TEMP_CLASS="unknown"
fi

echo " GPU:${TEMP}°C"
