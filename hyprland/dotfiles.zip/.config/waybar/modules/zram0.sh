#!/bin/bash

exec 2>/dev/null

# Check zram0 specifically
if [ ! -e /dev/zram0 ]; then
    echo "missing"
    exit 0
fi

# Try to get info from zramctl
if command -v zramctl >/dev/null; then
    info=$(zramctl /dev/zram0 --noheadings 2>/dev/null)
    if [ -n "$info" ]; then
        # Parse the output - adjust based on your format
        disksize=$(echo "$info" | awk '{print $3}')
        data=$(echo "$info" | awk '{print $4}')
        echo "$data/$disksize"
    else
        echo "inactive"
    fi
else
    echo "no zramctl"
fi
