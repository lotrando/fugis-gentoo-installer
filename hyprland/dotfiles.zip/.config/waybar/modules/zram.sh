#!/bin/bash

# Parameter: device number (0, 1, 2, ...)
DEVICE_NUM="$1"

exec 2>/dev/null

if [ -z "$DEVICE_NUM" ]; then
    echo "Usage: $0 <device_number>"
    exit 1
fi

DEVICE="/dev/zram$DEVICE_NUM"

if [ ! -b "$DEVICE" ]; then
    echo "zram$DEVICE_NUM: N/A"
    exit 0
fi

# Check if device is mounted
mount_info=$(mount | grep "zram$DEVICE_NUM")
swap_info=$(grep "zram$DEVICE_NUM" /proc/swaps 2>/dev/null)

if [ -n "$mount_info" ]; then
    # It's mounted as filesystem
    mount_point=$(echo "$mount_info" | awk '{print $3}')
    df_info=$(df -h "$mount_point" 2>/dev/null | tail -1)
    
    if [ -n "$df_info" ]; then
        used=$(echo "$df_info" | awk '{print $3}')
        total=$(echo "$df_info" | awk '{print $2}')
        percent=$(echo "$df_info" | awk '{print $5}' | tr -d '%')
        
        # Short mount point name
        short_mount=$(basename "$mount_point")
        echo "zram$DEVICE_NUM($short_mount): $used/$total ($percent%)"
    else
        echo "zram$DEVICE_NUM: Mounted (no data)"
    fi
    
elif [ -n "$swap_info" ]; then
    # It's used as swap
    size_kb=$(echo "$swap_info" | awk '{print $3}')
    used_kb=$(echo "$swap_info" | awk '{print $4}')
    
    size_mb=$((size_kb / 1024))
    used_mb=$((used_kb / 1024))
    
    if [ "$size_mb" -gt 0 ]; then
        percent=$((used_kb * 100 / size_kb))
        echo "zram$DEVICE_NUM(swap): ${used_mb}MB/${size_mb}MB ($percent%)"
    else
        echo "zram$DEVICE_NUM(swap): 0MB"
    fi
else
    # Check if it's configured but not active
    if [ -f "/sys/block/zram$DEVICE_NUM/disksize" ]; then
        disksize=$(cat "/sys/block/zram$DEVICE_NUM/disksize" 2>/dev/null || echo "0")
        if [ "$disksize" -gt 0 ]; then
            size_gb=$((disksize / 1024 / 1024 / 1024))
            echo "zram$DEVICE_NUM: ${size_gb}GB (unused)"
        else
            echo "zram$DEVICE_NUM: Not configured"
        fi
    else
        echo "zram$DEVICE_NUM: Not available"
    fi
fi
