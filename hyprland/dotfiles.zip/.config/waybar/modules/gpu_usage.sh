#!/bin/bash

GPU_USAGE_PATH="/sys/class/drm/card0/device/gpu_busy_percent"

get_gpu_usage() {
    if [[ -r "$GPU_USAGE_PATH" ]]; then
        cat "$GPU_USAGE_PATH"
    else
        echo "N/A"
    fi
}

USAGE=$(get_gpu_usage)

if [[ "$USAGE" =~ ^[0-9]+$ ]]; then
    if [ "$USAGE" -lt 25 ]; then
        USAGE_CLASS="idle"
    elif [ "$USAGE" -lt 75 ]; then
        USAGE_CLASS="active"
    else
        USAGE_CLASS="busy"
    fi
else
    USAGE_CLASS="unknown"
fi

echo " GPU:${USAGE}%"
