#!/bin/bash

TEMP_PATH="/sys/class/drm/card0/device/hwmon/hwmon3/temp1_input"
GPU_USAGE_PATH="/sys/class/drm/card0/device/gpu_busy_percent"

get_temperature() {
    if [[ -r "$TEMP_PATH" ]]; then
        temp=$(cat "$TEMP_PATH")
        echo $((temp / 1000))
    elif [[ -r "$ALT_TEMP_PATH" ]]; then
        temp=$(cat "$ALT_TEMP_PATH")
        echo $((temp / 1000))
    else
        if command -v sensors >/dev/null 2>&1; then
            sensors | grep -E "(amdgpu|radeon)" -A 10 | grep -E "temp.*°C" | head -1 | grep -oE '[0-9]+' | head -1
        else
            echo "N/A"
        fi
    fi
}

get_gpu_usage() {
    if [[ -r "$GPU_USAGE_PATH" ]]; then
        cat "$GPU_USAGE_PATH"
    else
        echo "N/A"
    fi
}

TEMP=$(get_temperature)
USAGE=$(get_gpu_usage)

if [[ "$TEMP" =~ ^[0-9]+$ ]]; then
    if [ "$TEMP" -lt 50 ]; then
        TEMP_CLASS="cold"
    elif [ "$TEMP" -lt 70 ]; then
        TEMP_CLASS="normal"
    elif [ "$TEMP" -lt 80 ]; then
        TEMP_CLASS="warm"
    else
        TEMP_CLASS="hot"
    fi
else
    TEMP_CLASS="unknown"
fi

if [[ "$USAGE" =~ ^[0-9]+$ ]]; then
    if [ "$USAGE" -lt 25 ]; then
        USAGE_CLASS="idle"
    elif [ "$USAGE" -lt 75 ]; then
        USAGE_CLASS="active"
    else
        USAGE_CLASS="busy"
    fi
else
    USAGE_CLASS="unknown"
fi

echo " GPU:${TEMP}°C  GPU:${USAGE}%"
