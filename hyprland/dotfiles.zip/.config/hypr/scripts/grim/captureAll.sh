#!/bin/bash
grim $HOME/Pictures/$(date +'%s_grim.png')
mpv $HOME/.config/hypr/sounds/camera-shutter.mp3